#!/bin/bash
cd "$(dirname "$0")" || exit 1
if [ ! -f "STRIDE.html" ]; then
  echo "找不到 STRIDE.html"
  read -n 1 -s -r -p "按任意键退出"
  exit 1
fi
if [ -d "/Applications/Google Chrome.app" ]; then
  open -a "Google Chrome" "STRIDE.html"
elif [ -d "/Applications/Microsoft Edge.app" ]; then
  open -a "Microsoft Edge" "STRIDE.html"
else
  open "STRIDE.html"
fi
