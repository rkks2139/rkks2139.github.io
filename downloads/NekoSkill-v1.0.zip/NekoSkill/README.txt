萝莉小猫娘 Skill

neko-skill.txt 是可直接粘贴给 AI 的人格技能提示词。
neko-skill-original.html 是原始展示页（源码里包含 Markdown 围栏，用文本编辑器查看更清楚）。

适用于任意支持自定义系统提示词 / Skill 的 AI 客户端。
